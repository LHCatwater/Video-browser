package app.longform;

import android.app.Activity;
import android.content.pm.PackageInfo;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsetsController;
import android.webkit.CookieManager;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

/** The "Customise" screen. Every change is saved straight away and applied when you go back. */
public class SettingsActivity extends Activity {

    private Ui.Pal p;
    private LinearLayout col;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        p = Ui.pal(this);
        getWindow().setStatusBarColor(p.page);
        getWindow().setNavigationBarColor(p.page);
        build();
        WindowInsetsController ic = getWindow().getInsetsController();
        if (ic != null) {
            int light = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
                    | WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
            ic.setSystemBarsAppearance(p.dark ? 0 : light, light);
        }
    }

    private void build() {
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(p.page);
        sv.setFillViewport(true);
        col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(16), dp(8), dp(16), dp(32));
        sv.addView(col);
        setContentView(sv);

        // Header
        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        ImageView back = new ImageView(this);
        back.setImageDrawable(Ui.icon(this, "ic_back", p.text));
        back.setScaleType(ImageView.ScaleType.CENTER);
        back.setBackground(Ui.press(0, dp(24), Ui.alpha(p.text, 0.12f)));
        back.setContentDescription("Back");
        back.setOnClickListener(v -> finish());
        head.addView(back, new LinearLayout.LayoutParams(dp(48), dp(48)));
        col.addView(head);

        TextView title = new TextView(this);
        title.setText("Customise");
        title.setTextSize(32);
        title.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        title.setTextColor(p.text);
        title.setPadding(dp(8), dp(20), 0, dp(4));
        col.addView(title);
        TextView tag = new TextView(this);
        tag.setText("YouTube, your way. Changes apply as soon as you go back.");
        tag.setTextSize(14);
        tag.setTextColor(p.sub);
        tag.setPadding(dp(8), 0, 0, dp(12));
        col.addView(tag);

        LinearLayout c;

        c = section("Shorts");
        toggle(c, "Hide on Home", null, Prefs.SHORTS_HOME);
        toggle(c, "Hide in Subscriptions", null, Prefs.SHORTS_SUBS);
        toggle(c, "Hide in search results", "Also removes the Shorts filter chip", Prefs.SHORTS_SEARCH);
        toggle(c, "Hide under videos", "The Up next list on a video page", Prefs.SHORTS_WATCH);
        toggle(c, "Hide everywhere else", "Explore, history, playlists and other pages", Prefs.SHORTS_OTHER);
        toggle(c, "Keep Shorts on channel pages", "A creator's Shorts still show on their page", Prefs.SHORTS_CHANNEL);
        toggle(c, "Play Shorts in the normal player", "Any Short you open plays as a regular video, with full controls", Prefs.SHORTS_PLAYER);

        c = section("Ads");
        toggle(c, "Block ads", "Hides ads in feeds and blocks ad servers. Premium already removes most ads", Prefs.AD_BLOCK);
        toggle(c, "Skip video ads automatically", "Mutes and fast-forwards any ad that still plays", Prefs.AD_SKIP);
        toggle(c, "Hide Premium and promo banners", null, Prefs.HIDE_PROMOS);

        c = section("Feed");
        choice(c, "Videos per row on Home", Prefs.COLUMNS,
                new String[]{"1 (YouTube's layout)", "2", "3"}, new String[]{"1", "2", "3"});
        toggle(c, "Hide videos you've watched", "Videos with a red progress bar", Prefs.HIDE_WATCHED);
        toggle(c, "Hide Mixes", "Auto-made playlists", Prefs.HIDE_MIXES);
        toggle(c, "Hide community posts", "On Home and Subscriptions", Prefs.HIDE_POSTS);
        toggle(c, "Hide Playables", "YouTube's mini games", Prefs.HIDE_GAMES);
        toggle(c, "Hide comments under videos", null, Prefs.HIDE_COMMENTS);

        c = section("Look");
        choice(c, "Theme", Prefs.THEME,
                new String[]{"Match phone", "Light", "Dark", "Black (AMOLED)"},
                new String[]{"system", "light", "dark", "black"});
        colours(c);
        toggle(c, "Accent on progress bars", "Colours the video and thumbnail progress bars", Prefs.ACCENT_PROGRESS);
        choice(c, "Thumbnail corners", Prefs.CORNERS,
                new String[]{"YouTube's own", "Square", "Soft", "Round", "Extra round"},
                new String[]{"-1", "0", "6", "12", "20"});
        slider(c, "Text size", Prefs.TEXT_SIZE, 80, 150, 5);
        choice(c, "Navigation bar", Prefs.NAV_STYLE,
                new String[]{"Floating", "Flat"}, new String[]{"floating", "flat"});
        toggle(c, "Show labels on navigation bar", null, Prefs.NAV_LABELS);
        toggle(c, "Search button on navigation bar", null, Prefs.NAV_SEARCH);

        c = section("Player");
        choice(c, "Default playback speed", Prefs.SPEED,
                new String[]{"0.5×", "0.75×", "Normal", "1.25×", "1.5×", "1.75×", "2×"},
                new String[]{"0.5", "0.75", "1", "1.25", "1.5", "1.75", "2"});
        choice(c, "Full-screen rotation", Prefs.ROTATE,
                new String[]{"Match the video", "Always landscape", "Don't rotate"},
                new String[]{"auto", "landscape", "none"});
        toggle(c, "Picture-in-picture", "Keep watching in a small window when you leave the app", Prefs.PIP);
        toggle(c, "Keep screen on while playing", null, Prefs.KEEP_AWAKE);

        c = section("Browsing");
        choice(c, "Open the app on", Prefs.START,
                new String[]{"Home", "Subscriptions", "You"}, new String[]{"home", "subs", "you"});
        toggle(c, "Open other websites in your browser", "Off: they open inside this app", Prefs.EXTERNAL);
        toggle(c, "Search suggestions", null, Prefs.SUGGEST);
        toggle(c, "Remember searches", null, Prefs.REMEMBER);
        action(c, "Clear search history", null, () -> {
            Prefs.clearRecent(this);
            toast("Search history cleared");
        });

        c = section("Account");
        boolean signedIn = MainActivity.isSignedIn();
        action(c, signedIn ? "Switch Google account" : "Sign in to YouTube",
                signedIn ? "You're signed in" : "Link your YouTube account and Premium", () -> {
            Prefs.sp(this).edit().putBoolean(Prefs.PENDING_SIGN_IN, true).apply();
            finish();
        });

        c = section("Data");
        action(c, "Reload YouTube", "Starts again from your start page", () -> {
            Prefs.sp(this).edit().putBoolean(Prefs.PENDING_RELOAD, true).apply();
            finish();
        });
        action(c, "Clear cache", "Frees up space. You stay signed in", () -> {
            WebView w = new WebView(this);
            w.clearCache(true);
            w.destroy();
            toast("Cache cleared");
        });
        action(c, "Sign out and clear all data", "Removes cookies, sign-in and site data", () ->
                new Sheet(this, "Sign out and clear everything?")
                        .row("ic_check", "Yes, clear it all", null, false, () -> {
                            CookieManager cm = CookieManager.getInstance();
                            cm.removeAllCookies(ok -> cm.flush());
                            WebStorage.getInstance().deleteAllData();
                            WebView w = new WebView(this);
                            w.clearCache(true);
                            w.clearHistory();
                            w.destroy();
                            Prefs.sp(this).edit().putBoolean(Prefs.PENDING_RELOAD, true).apply();
                            toast("Signed out and cleared");
                        })
                        .row("ic_close", "Cancel", null, false, null)
                        .show());
        action(c, "Reset all settings", "Search history is kept", () ->
                new Sheet(this, "Reset every setting?")
                        .row("ic_refresh", "Yes, reset", null, false, () -> {
                            Prefs.reset(this);
                            Ui.applyNightMode(this);
                            recreate();
                        })
                        .row("ic_close", "Cancel", null, false, null)
                        .show());

        TextView about = new TextView(this);
        String ver = "";
        try {
            PackageInfo pi = getPackageManager().getPackageInfo(getPackageName(), 0);
            ver = " " + pi.versionName;
        } catch (Exception ignored) {}
        about.setText("Longform" + ver + "\nA calmer way to watch YouTube.");
        about.setTextSize(13);
        about.setTextColor(p.sub);
        about.setGravity(Gravity.CENTER);
        about.setPadding(0, dp(24), 0, 0);
        col.addView(about);
    }

    // ---------- Building blocks ----------

    private LinearLayout section(String name) {
        TextView h = new TextView(this);
        h.setText(name.toUpperCase());
        h.setTextSize(12);
        h.setLetterSpacing(0.08f);
        h.setTypeface(Typeface.DEFAULT_BOLD);
        h.setTextColor(p.accent);
        h.setPadding(dp(12), dp(22), 0, dp(8));
        col.addView(h);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(Ui.round(p.card, dp(22)));
        card.setClipToOutline(true);
        card.setPadding(0, dp(4), 0, dp(4));
        col.addView(card, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        return card;
    }

    /** A row with a title and optional grey subtitle. Returns {row, subtitle}. */
    private Object[] row(LinearLayout card, String title, String sub, View end) {
        if (card.getChildCount() > 0) {
            View line = new View(this);
            line.setBackgroundColor(p.line);
            LinearLayout.LayoutParams ll = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1);
            ll.leftMargin = dp(20);
            ll.rightMargin = dp(20);
            card.addView(line, ll);
        }
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setMinimumHeight(dp(60));
        row.setPadding(dp(20), dp(12), dp(16), dp(12));
        row.setBackground(Ui.press(0, 0, Ui.alpha(p.text, 0.08f)));

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        TextView t = new TextView(this);
        t.setText(title);
        t.setTextSize(16);
        t.setTextColor(p.text);
        texts.addView(t);
        TextView s = new TextView(this);
        s.setTextSize(13);
        s.setTextColor(p.sub);
        s.setPadding(0, dp(2), 0, 0);
        if (sub == null) s.setVisibility(View.GONE); else s.setText(sub);
        texts.addView(s);
        row.addView(texts, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        if (end != null) {
            LinearLayout.LayoutParams el = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            el.leftMargin = dp(12);
            row.addView(end, el);
        }
        card.addView(row, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        return new Object[]{row, s};
    }

    private void toggle(LinearLayout card, String title, String sub, String key) {
        Switch sw = new Switch(this);
        sw.setChecked(Prefs.bool(this, key));
        int[][] states = {{android.R.attr.state_checked}, {}};
        sw.setThumbTintList(new ColorStateList(states, new int[]{p.accent, p.dark ? 0xFFBDBDBD : 0xFFFFFFFF}));
        sw.setTrackTintList(new ColorStateList(states, new int[]{Ui.alpha(p.accent, 0.5f), Ui.alpha(p.text, 0.25f)}));
        sw.setOnCheckedChangeListener((v, on) -> Prefs.put(this, key, on));
        Object[] r = row(card, title, sub, sw);
        ((View) r[0]).setOnClickListener(v -> sw.toggle());
    }

    private void choice(LinearLayout card, String title, String key, String[] labels, String[] values) {
        ImageView chev = new ImageView(this);
        chev.setImageDrawable(Ui.icon(this, "ic_chevron", p.sub));
        Object[] r = row(card, title, labelFor(key, labels, values), chev);
        TextView sub = (TextView) r[1];
        sub.setTextColor(p.accent);
        ((View) r[0]).setOnClickListener(v -> {
            String cur = Prefs.str(this, key);
            Sheet s = new Sheet(this, title);
            for (int i = 0; i < labels.length; i++) {
                final String val = values[i];
                s.row(null, labels[i], null, val.equals(cur), () -> {
                    Prefs.put(this, key, val);
                    sub.setText(labelFor(key, labels, values));
                    if (Prefs.THEME.equals(key)) {
                        Ui.applyNightMode(this);
                        recreate();
                    }
                });
            }
            s.show();
        });
    }

    private String labelFor(String key, String[] labels, String[] values) {
        String cur = Prefs.str(this, key);
        for (int i = 0; i < values.length; i++) if (values[i].equals(cur)) return labels[i];
        return labels[0];
    }

    private void slider(LinearLayout card, String title, String key, int min, int max, int step) {
        TextView value = new TextView(this);
        value.setTextSize(15);
        value.setTypeface(Typeface.DEFAULT_BOLD);
        value.setTextColor(p.accent);
        int cur = Prefs.num(this, key);
        value.setText(cur + "%");
        Object[] r = row(card, title, null, value);
        LinearLayout row = (LinearLayout) r[0];
        row.setBackground(null);

        SeekBar sb = new SeekBar(this);
        sb.setMax((max - min) / step);
        sb.setProgress((cur - min) / step);
        sb.setProgressTintList(ColorStateList.valueOf(p.accent));
        sb.setThumbTintList(ColorStateList.valueOf(p.accent));
        sb.setProgressBackgroundTintList(ColorStateList.valueOf(Ui.alpha(p.text, 0.3f)));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int prog, boolean user) {
                value.setText((min + prog * step) + "%");
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {
                Prefs.put(SettingsActivity.this, key, min + s.getProgress() * step);
            }
        });
        LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        sl.leftMargin = dp(4);
        sl.rightMargin = dp(4);
        sl.bottomMargin = dp(10);
        card.addView(sb, sl);
    }

    private void colours(LinearLayout card) {
        Object[] r = row(card, "Accent colour", Ui.ACCENT_NAMES[Prefs.num(this, Prefs.ACCENT) % Ui.ACCENTS.length], null);
        LinearLayout row = (LinearLayout) r[0];
        row.setBackground(null);
        TextView sub = (TextView) r[1];
        sub.setTextColor(p.accent);

        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        hs.setOverScrollMode(View.OVER_SCROLL_NEVER);
        LinearLayout dots = new LinearLayout(this);
        dots.setPadding(dp(16), 0, dp(16), dp(14));
        hs.addView(dots);
        card.addView(hs);

        View[] views = new View[Ui.ACCENTS.length];
        for (int i = 0; i < Ui.ACCENTS.length; i++) {
            final int idx = i;
            View dot = new View(this);
            dot.setContentDescription(Ui.ACCENT_NAMES[i]);
            views[i] = dot;
            LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(dp(38), dp(38));
            dl.rightMargin = dp(10);
            dots.addView(dot, dl);
            dot.setOnClickListener(v -> {
                Prefs.put(this, Prefs.ACCENT, idx);
                sub.setText(Ui.ACCENT_NAMES[idx]);
                paintDots(views);
            });
        }
        paintDots(views);
    }

    private void paintDots(View[] views) {
        int sel = Prefs.num(this, Prefs.ACCENT);
        for (int i = 0; i < views.length; i++) {
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setColor(Ui.ACCENTS[i]);
            if (i == sel) g.setStroke(dp(3), p.text);
            views[i].setBackground(g);
            views[i].setScaleX(i == sel ? 1.08f : 1f);
            views[i].setScaleY(i == sel ? 1.08f : 1f);
        }
    }

    private void action(LinearLayout card, String title, String sub, Runnable r) {
        Object[] row = row(card, title, sub, null);
        ((View) row[0]).setOnClickListener(v -> r.run());
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private int dp(float v) {
        return Ui.dp(this, v);
    }
}
