package app.longform;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** All of the app's settings, with their defaults. */
final class Prefs {
    private Prefs() {}

    static final String FILE = "longform";

    // Shorts
    static final String SHORTS_HOME = "shorts_home";
    static final String SHORTS_SUBS = "shorts_subs";
    static final String SHORTS_SEARCH = "shorts_search";
    static final String SHORTS_WATCH = "shorts_watch";
    static final String SHORTS_OTHER = "shorts_other";
    static final String SHORTS_CHANNEL = "shorts_channel"; // true = keep them on channel pages
    static final String SHORTS_PLAYER = "shorts_player";   // open Shorts in the normal player

    // Ads
    static final String AD_BLOCK = "ad_block";
    static final String AD_SKIP = "ad_skip";
    static final String HIDE_PROMOS = "hide_promos";

    // Feed
    static final String COLUMNS = "columns";
    static final String HIDE_WATCHED = "hide_watched";
    static final String HIDE_MIXES = "hide_mixes";
    static final String HIDE_POSTS = "hide_posts";
    static final String HIDE_GAMES = "hide_games";
    static final String HIDE_COMMENTS = "hide_comments";

    // Look
    static final String THEME = "theme";               // system | light | dark | black
    static final String ACCENT = "accent";             // index into Ui.ACCENTS
    static final String ACCENT_PROGRESS = "accent_progress";
    static final String CORNERS = "corners";           // -1 = YouTube's own, else px
    static final String TEXT_SIZE = "text_size";       // percent
    static final String NAV_STYLE = "nav_style";       // floating | flat
    static final String NAV_LABELS = "nav_labels";
    static final String NAV_SEARCH = "nav_search";

    // Player
    static final String SPEED = "speed";
    static final String ROTATE = "rotate";             // auto | landscape | none
    static final String PIP = "pip";
    static final String KEEP_AWAKE = "keep_awake";

    // Browsing
    static final String START = "start";              // home | subs | you
    static final String EXTERNAL = "external";
    static final String SUGGEST = "suggest";
    static final String REMEMBER = "remember";
    static final String RECENT = "recent";

    // Internal
    static final String REV = "rev";
    static final String PENDING_RELOAD = "pending_reload";
    static final String PENDING_SIGN_IN = "pending_sign_in";

    private static final Map<String, Object> DEF = new HashMap<>();
    static {
        DEF.put(SHORTS_HOME, true);
        DEF.put(SHORTS_SUBS, true);
        DEF.put(SHORTS_SEARCH, true);
        DEF.put(SHORTS_WATCH, true);
        DEF.put(SHORTS_OTHER, true);
        DEF.put(SHORTS_CHANNEL, true);
        DEF.put(SHORTS_PLAYER, false);

        DEF.put(AD_BLOCK, true);
        DEF.put(AD_SKIP, true);
        DEF.put(HIDE_PROMOS, true);

        DEF.put(COLUMNS, "1");
        DEF.put(HIDE_WATCHED, false);
        DEF.put(HIDE_MIXES, false);
        DEF.put(HIDE_POSTS, false);
        DEF.put(HIDE_GAMES, true);
        DEF.put(HIDE_COMMENTS, false);

        DEF.put(THEME, "system");
        DEF.put(ACCENT, 0);
        DEF.put(ACCENT_PROGRESS, true);
        DEF.put(CORNERS, "12");
        DEF.put(TEXT_SIZE, 100);
        DEF.put(NAV_STYLE, "floating");
        DEF.put(NAV_LABELS, true);
        DEF.put(NAV_SEARCH, true);

        DEF.put(SPEED, "1");
        DEF.put(ROTATE, "auto");
        DEF.put(PIP, true);
        DEF.put(KEEP_AWAKE, true);

        DEF.put(START, "home");
        DEF.put(EXTERNAL, true);
        DEF.put(SUGGEST, true);
        DEF.put(REMEMBER, true);
        DEF.put(RECENT, "[]");
    }

    static SharedPreferences sp(Context c) {
        return c.getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    static boolean bool(Context c, String k) {
        Object d = DEF.get(k);
        return sp(c).getBoolean(k, d instanceof Boolean && (Boolean) d);
    }

    static String str(Context c, String k) {
        Object d = DEF.get(k);
        return sp(c).getString(k, d == null ? "" : String.valueOf(d));
    }

    static int num(Context c, String k) {
        Object d = DEF.get(k);
        return sp(c).getInt(k, d instanceof Integer ? (Integer) d : 0);
    }

    static int strAsInt(Context c, String k, int fallback) {
        try { return Integer.parseInt(str(c, k)); } catch (NumberFormatException e) { return fallback; }
    }

    /** Saves a setting and bumps the revision so the browser re-applies everything. */
    static void put(Context c, String k, Object v) {
        SharedPreferences s = sp(c);
        SharedPreferences.Editor e = s.edit();
        if (v instanceof Boolean) e.putBoolean(k, (Boolean) v);
        else if (v instanceof Integer) e.putInt(k, (Integer) v);
        else e.putString(k, String.valueOf(v));
        e.putInt(REV, s.getInt(REV, 0) + 1).apply();
    }

    /** Resets every setting except search history. */
    static void reset(Context c) {
        SharedPreferences s = sp(c);
        String recent = s.getString(RECENT, "[]");
        int rev = s.getInt(REV, 0);
        s.edit().clear().putString(RECENT, recent).putInt(REV, rev + 1).apply();
    }

    /** The settings the page script needs, as JSON. */
    static JSONObject toJs(Context c) {
        JSONObject o = new JSONObject();
        try {
            o.put("shortsHome", bool(c, SHORTS_HOME));
            o.put("shortsSubs", bool(c, SHORTS_SUBS));
            o.put("shortsSearch", bool(c, SHORTS_SEARCH));
            o.put("shortsWatch", bool(c, SHORTS_WATCH));
            o.put("shortsOther", bool(c, SHORTS_OTHER));
            o.put("shortsChannel", bool(c, SHORTS_CHANNEL));
            o.put("shortsToPlayer", bool(c, SHORTS_PLAYER));
            o.put("adBlock", bool(c, AD_BLOCK));
            o.put("adSkip", bool(c, AD_SKIP));
            o.put("hidePromos", bool(c, HIDE_PROMOS));
            o.put("cols", strAsInt(c, COLUMNS, 1));
            o.put("hideWatched", bool(c, HIDE_WATCHED));
            o.put("hideMixes", bool(c, HIDE_MIXES));
            o.put("hidePosts", bool(c, HIDE_POSTS));
            o.put("hideGames", bool(c, HIDE_GAMES));
            o.put("hideComments", bool(c, HIDE_COMMENTS));
            o.put("black", "black".equals(str(c, THEME)) && Ui.isDark(c));
            o.put("accent", String.format("#%06X", Ui.accent(c) & 0xFFFFFF));
            o.put("accentProgress", bool(c, ACCENT_PROGRESS));
            o.put("radius", strAsInt(c, CORNERS, -1));
            double speed = 1;
            try { speed = Double.parseDouble(str(c, SPEED)); } catch (NumberFormatException ignored) {}
            o.put("speed", speed);
        } catch (JSONException ignored) {
        }
        return o;
    }

    // ---- Search history ----

    static List<String> recent(Context c) {
        List<String> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(str(c, RECENT));
            for (int i = 0; i < a.length(); i++) out.add(a.getString(i));
        } catch (JSONException ignored) {
        }
        return out;
    }

    private static void saveRecent(Context c, List<String> list) {
        JSONArray a = new JSONArray();
        for (String s : list) a.put(s);
        sp(c).edit().putString(RECENT, a.toString()).apply();
    }

    static void addRecent(Context c, String q) {
        if (!bool(c, REMEMBER)) return;
        List<String> list = recent(c);
        for (int i = list.size() - 1; i >= 0; i--) if (list.get(i).equalsIgnoreCase(q)) list.remove(i);
        list.add(0, q);
        while (list.size() > 30) list.remove(list.size() - 1);
        saveRecent(c, list);
    }

    static void removeRecent(Context c, String q) {
        List<String> list = recent(c);
        list.remove(q);
        saveRecent(c, list);
    }

    static void clearRecent(Context c) {
        saveRecent(c, new ArrayList<>());
    }
}
