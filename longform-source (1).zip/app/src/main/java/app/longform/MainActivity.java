package app.longform;

import android.app.Activity;
import android.app.PendingIntent;
import android.app.PictureInPictureParams;
import android.app.RemoteAction;
import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Rational;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** The browser: YouTube's mobile site, with the app's own bar, search and filters on top. */
public class MainActivity extends Activity implements NavBar.Listener, SearchPanel.Listener {

    static final String BASE = "https://m.youtube.com";
    private static final String ACTION_PIP = "app.longform.PIP_PLAY_PAUSE";

    private final Handler ui = new Handler(Looper.getMainLooper());

    private FrameLayout root, fullscreen;
    private WebView web;
    private View progress, loading;
    private NavBar nav;
    private SearchPanel search;
    private Chrome chrome;

    private Ui.Pal pal;
    private boolean createdDark;
    private int appliedRev = -1;
    private String jsCore = "", cssCore = "", script = "";
    private volatile boolean adBlock = true;
    private String chromeUa = "", googleUa = "";

    /** YouTube's normal sign-in page; after signing in it comes back to the mobile site. */
    static final String SIGN_IN_URL = "https://accounts.google.com/ServiceLogin?service=youtube&uilel=3&passive=true"
            + "&continue=" + Uri.encode("https://www.youtube.com/signin?action_handle_signin=true&app=m&hl=en&next="
            + Uri.encode(BASE + "/"));

    private String currentUrl = BASE + "/";
    private View customView;
    private WebChromeClient.CustomViewCallback customCb;
    private boolean playing;
    private float videoAspect = 16f / 9f;
    private boolean firstLoadDone;

    private final BroadcastReceiver pipReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            js("window.__LF&&__LF.toggle()");
        }
    };

    // ------------------------------------------------------------------ lifecycle

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        pal = Ui.pal(this);
        createdDark = pal.dark;
        jsCore = readAsset("inject.js");
        cssCore = readAsset("inject.css");

        buildViews();
        styleBars();
        setupWeb();
        applyPrefs(false);

        IntentFilter f = new IntentFilter(ACTION_PIP);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(pipReceiver, f, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(pipReceiver, f);

        boolean restored = saved != null && web.restoreState(saved) != null;
        if (!restored) {
            String u = urlFromIntent(getIntent());
            web.loadUrl(u != null ? u : startUrl());
        }
        ui.postDelayed(this::hideLoading, 7000); // never get stuck on the loading screen
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        String u = urlFromIntent(intent);
        if (u != null) {
            if (customView != null) chrome.onHideCustomView();
            if (search.isOpen()) search.close();
            web.loadUrl(u);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (Ui.isDark(this) != createdDark) {
            recreate();
            return;
        }
        if (Prefs.num(this, Prefs.REV) != appliedRev) applyPrefs(true);
        if (Prefs.sp(this).getBoolean(Prefs.PENDING_SIGN_IN, false)) {
            Prefs.sp(this).edit().remove(Prefs.PENDING_SIGN_IN).remove(Prefs.PENDING_RELOAD).apply();
            signIn();
        }
        if (Prefs.sp(this).getBoolean(Prefs.PENDING_RELOAD, false)) {
            Prefs.sp(this).edit().remove(Prefs.PENDING_RELOAD).apply();
            web.clearHistory();
            web.loadUrl(startUrl());
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        CookieManager.getInstance().flush(); // keep you signed in
        // Closing the picture-in-picture window (or leaving without it) pauses the video.
        js("window.__LF&&__LF.pause()");
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    @Override
    protected void onDestroy() {
        try { unregisterReceiver(pipReceiver); } catch (Exception ignored) {}
        if (web != null) {
            if (web.getParent() instanceof ViewGroup) ((ViewGroup) web.getParent()).removeView(web);
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }

    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() {
        if (customView != null) { chrome.onHideCustomView(); return; }
        if (search.isOpen()) { search.close(); return; }
        if (web.canGoBack()) { web.goBack(); return; }
        super.onBackPressed();
    }

    // ------------------------------------------------------------------ views

    private void buildViews() {
        root = new FrameLayout(this);
        root.setBackgroundColor(pal.bg);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);

        FrameLayout webBox = new FrameLayout(this);
        web = new WebView(this);
        web.setBackgroundColor(pal.bg);
        webBox.addView(web, new FrameLayout.LayoutParams(-1, -1));

        progress = new View(this);
        progress.setBackgroundColor(pal.accent);
        progress.setPivotX(0);
        progress.setScaleX(0);
        progress.setAlpha(0);
        webBox.addView(progress, new FrameLayout.LayoutParams(-1, Ui.dp(this, 2.5f), Gravity.TOP));

        content.addView(webBox, new LinearLayout.LayoutParams(-1, 0, 1f));
        nav = new NavBar(this, this);
        content.addView(nav, new LinearLayout.LayoutParams(-1, -2));
        root.addView(content, new FrameLayout.LayoutParams(-1, -1));

        fullscreen = new FrameLayout(this);
        fullscreen.setBackgroundColor(Color.BLACK);
        fullscreen.setVisibility(View.GONE);
        root.addView(fullscreen, new FrameLayout.LayoutParams(-1, -1));

        search = new SearchPanel(this, this);
        search.setVisibility(View.GONE);
        root.addView(search, new FrameLayout.LayoutParams(-1, -1));

        loading = buildLoading();
        root.addView(loading, new FrameLayout.LayoutParams(-1, -1));

        setContentView(root);
    }

    private View buildLoading() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setBackgroundColor(pal.bg);
        box.setClickable(true);
        ProgressBar spin = new ProgressBar(this);
        spin.setIndeterminateTintList(ColorStateList.valueOf(pal.accent));
        box.addView(spin, new LinearLayout.LayoutParams(Ui.dp(this, 40), Ui.dp(this, 40)));
        TextView t = new TextView(this);
        t.setText("Longform");
        t.setTextColor(pal.sub);
        t.setTextSize(14);
        t.setPadding(0, Ui.dp(this, 14), 0, 0);
        box.addView(t);
        return box;
    }

    private void hideLoading() {
        if (loading == null || loading.getVisibility() != View.VISIBLE) return;
        loading.animate().alpha(0f).setDuration(220).withEndAction(() -> loading.setVisibility(View.GONE)).start();
    }

    private void styleBars() {
        getWindow().setStatusBarColor(pal.bg);
        getWindow().setNavigationBarColor(pal.bg);
        WindowInsetsController c = getWindow().getInsetsController();
        if (c != null) {
            int light = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
                    | WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
            c.setSystemBarsAppearance(pal.dark ? 0 : light, light);
        }
    }

    private void showProgress(int p) {
        if (p >= 100) {
            progress.animate().scaleX(1f).setDuration(150).withEndAction(() ->
                    progress.animate().alpha(0f).setDuration(250).start()).start();
        } else {
            progress.setAlpha(1f);
            progress.animate().scaleX(Math.max(0.05f, p / 100f)).setDuration(200).start();
        }
    }

    // ------------------------------------------------------------------ settings

    /** Re-reads every setting and pushes it to the bar and the page. */
    private void applyPrefs(boolean live) {
        Ui.Pal np = Ui.pal(this);
        if (live && np.bg != pal.bg) {
            recreate();
            return;
        }
        pal = np;
        appliedRev = Prefs.num(this, Prefs.REV);
        adBlock = Prefs.bool(this, Prefs.AD_BLOCK);
        web.getSettings().setTextZoom(Prefs.num(this, Prefs.TEXT_SIZE));
        progress.setBackgroundColor(pal.accent);
        nav.build(pal, Prefs.str(this, Prefs.NAV_STYLE), Prefs.bool(this, Prefs.NAV_LABELS),
                Prefs.bool(this, Prefs.NAV_SEARCH));
        nav.select(tabFor(currentUrl));
        search.build(pal);
        search.setVisibility(View.GONE);
        script = "window.__LF_CFG=" + Prefs.toJs(this) + ";window.__LF_CSS="
                + JSONObject.quote(cssCore) + ";\n" + jsCore;
        if (live) inject();
        updateKeepAwake();
        updatePip();
    }

    private String startUrl() {
        String s = Prefs.str(this, Prefs.START);
        if ("subs".equals(s)) return BASE + "/feed/subscriptions";
        if ("you".equals(s)) return BASE + "/feed/you";
        return BASE + "/";
    }

    // ------------------------------------------------------------------ web view

    private void setupWeb() {
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportMultipleWindows(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        chromeUa = chromeUserAgent(s.getUserAgentString());
        googleUa = "Mozilla/5.0 (Android " + Build.VERSION.RELEASE + "; Mobile; rv:145.0) Gecko/145.0 Firefox/145.0";
        s.setUserAgentString(chromeUa);

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(web, true);

        web.addJavascriptInterface(new Bridge(), "LFNative");
        web.setWebViewClient(new Client());
        chrome = new Chrome();
        web.setWebChromeClient(chrome);
    }

    /** Looks like normal Chrome, so Google sign-in and YouTube's full mobile site work. */
    static String chromeUserAgent(String ua) {
        return ua.replace("; wv)", ")")
                .replaceAll(" Build/[^;)]*", "")
                .replaceAll("Version/\\d+(\\.\\d+)* ", "");
    }

    private void inject() {
        if (isYouTube(currentHost())) web.evaluateJavascript(script, null);
    }

    private void js(String code) {
        if (web != null) web.evaluateJavascript(code, null);
    }

    private String currentHost() {
        String u = web.getUrl();
        if (u == null) u = currentUrl;
        String h = Uri.parse(u).getHost();
        return h == null ? "" : h.toLowerCase(Locale.ROOT);
    }

    static boolean isYouTube(String h) {
        return h.equals("youtube.com") || h.endsWith(".youtube.com");
    }

    /** Google's own pages (sign-in, account settings), not YouTube. */
    static boolean isGoogle(String h) {
        return h.matches("(.*\\.)?google\\.[a-z.]+");
    }

    /**
     * Google refuses to sign in from "embedded" browsers like this one. Its sign-in pages are
     * happy with a Firefox identity, so the app uses that on Google's pages and switches back
     * to Chrome for YouTube. Returns true if the page had to be reloaded with the other identity.
     */
    private boolean matchIdentity(Uri u, String h) {
        String want = isGoogle(h) ? googleUa : chromeUa;
        WebSettings s = web.getSettings();
        if (want.isEmpty() || want.equals(s.getUserAgentString())) return false;
        s.setUserAgentString(want);
        web.loadUrl(u.toString());
        return true;
    }

    static boolean isSignedIn() {
        String c = CookieManager.getInstance().getCookie("https://www.youtube.com");
        return c != null && (c.contains("LOGIN_INFO=") || c.contains("SAPISID="));
    }

    void signIn() {
        if (search.isOpen()) search.close();
        Uri u = Uri.parse(SIGN_IN_URL);
        if (!matchIdentity(u, u.getHost())) web.loadUrl(SIGN_IN_URL);
    }

    /** Pages that should stay inside the app (YouTube and Google sign-in). */
    static boolean isInternal(String h) {
        return isYouTube(h) || h.equals("youtu.be")
                || h.matches("(.*\\.)?google\\.[a-z.]+")
                || h.endsWith(".gstatic.com") || h.endsWith(".googleusercontent.com")
                || h.endsWith("youtube-nocookie.com");
    }

    /** Turns any YouTube link into the m.youtube.com address this app uses. */
    static String normalise(Uri u) {
        String h = u.getHost() == null ? "" : u.getHost().toLowerCase(Locale.ROOT);
        String q = u.getEncodedQuery();
        if (h.equals("youtu.be")) {
            String id = u.getPath() == null ? "" : u.getPath().replace("/", "");
            if (id.isEmpty()) return BASE + "/";
            return BASE + "/watch?v=" + id + (q != null ? "&" + q : "");
        }
        if (isYouTube(h) && !h.startsWith("music.")) {
            String path = u.getEncodedPath() == null ? "/" : u.getEncodedPath();
            return BASE + path + (q != null ? "?" + q : "");
        }
        return null;
    }

    private String urlFromIntent(Intent i) {
        if (i == null || i.getAction() == null) return null;
        Uri d = null;
        if (Intent.ACTION_VIEW.equals(i.getAction())) {
            d = i.getData();
        } else if (Intent.ACTION_SEND.equals(i.getAction())) {
            String t = i.getStringExtra(Intent.EXTRA_TEXT);
            if (t != null) {
                Matcher m = Pattern.compile("https?://\\S+").matcher(t);
                if (m.find()) d = Uri.parse(m.group());
            }
        }
        if (d == null) return null;
        String n = normalise(d);
        if (n == null) Toast.makeText(this, "That isn't a YouTube link", Toast.LENGTH_SHORT).show();
        return n;
    }

    /** Decides what happens when the page tries to open a link. True = handled here. */
    private boolean route(Uri u) {
        String scheme = u.getScheme() == null ? "" : u.getScheme().toLowerCase(Locale.ROOT);
        String h = u.getHost() == null ? "" : u.getHost().toLowerCase(Locale.ROOT);

        if (scheme.equals("intent")) {
            try {
                Intent i = Intent.parseUri(u.toString(), Intent.URI_INTENT_SCHEME);
                String fb = i.getStringExtra("browser_fallback_url");
                if (fb != null) {
                    Uri f = Uri.parse(fb);
                    String fh = f.getHost() == null ? "" : f.getHost().toLowerCase(Locale.ROOT);
                    if (isInternal(fh)) web.loadUrl(fb); else openExternal(f);
                }
            } catch (Exception ignored) {}
            return true;
        }
        if (!scheme.equals("http") && !scheme.equals("https")) {
            if (!scheme.startsWith("vnd.youtube")) openExternal(u);
            return true;
        }
        if (isYouTube(h) && "/redirect".equals(u.getPath())) {
            String q = u.getQueryParameter("q");
            if (q != null) { openExternal(Uri.parse(q)); return true; }
        }
        if (h.equals("youtu.be")) {
            String n = normalise(u);
            if (n != null) web.loadUrl(n);
            return true;
        }
        if (isInternal(h)) return matchIdentity(u, h);
        if (Prefs.bool(this, Prefs.EXTERNAL)) { openExternal(u); return true; }
        return false;
    }

    private void openExternal(Uri u) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, u);
            i.addCategory(Intent.CATEGORY_BROWSABLE);
            startActivity(i);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "No app can open that link", Toast.LENGTH_SHORT).show();
        }
    }

    private void onUrl(String url) {
        if (url == null) return;
        currentUrl = url;
        nav.select(tabFor(url));
        if (!onWatchPage()) playing = false;
        updateKeepAwake();
        updatePip();
        js("window.__LF&&__LF.refresh()");
    }

    private static String tabFor(String url) {
        Uri u = Uri.parse(url);
        String p = u.getPath() == null ? "/" : u.getPath();
        if (p.isEmpty() || p.equals("/")) return NavBar.HOME;
        if (p.startsWith("/feed/subscriptions")) return NavBar.SUBS;
        if (p.startsWith("/results")) return NavBar.SEARCH;
        if (p.startsWith("/feed/you") || p.startsWith("/feed/library") || p.startsWith("/feed/history")
                || p.startsWith("/feed/playlists") || p.startsWith("/playlist")) return NavBar.YOU;
        return null;
    }

    private boolean onWatchPage() {
        String p = Uri.parse(currentUrl).getPath();
        return p != null && p.startsWith("/watch");
    }

    private final class Client extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
            if (!r.isForMainFrame()) return false;
            return route(r.getUrl());
        }

        @Override
        public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
            if (adBlock && AdBlock.blocked(r.getUrl())) return AdBlock.empty();
            return null;
        }

        @Override
        public void onPageStarted(WebView v, String url, Bitmap icon) {
            currentUrl = url;
            showProgress(5);
        }

        @Override
        public void onPageCommitVisible(WebView v, String url) {
            inject();
        }

        @Override
        public void onPageFinished(WebView v, String url) {
            inject();
            showProgress(100);
            if (!firstLoadDone) {
                firstLoadDone = true;
                ui.postDelayed(MainActivity.this::hideLoading, 350);
            }
        }

        @Override
        public void doUpdateVisitedHistory(WebView v, String url, boolean reload) {
            onUrl(url);
        }

        @Override
        public boolean onRenderProcessGone(WebView v, RenderProcessGoneDetail d) {
            // The page crashed. Start over with a fresh browser.
            ((ViewGroup) web.getParent()).removeView(web);
            web.destroy();
            web = null;
            startActivity(new Intent(MainActivity.this, MainActivity.class));
            finish();
            return true;
        }
    }

    private final class Chrome extends WebChromeClient {
        @Override
        public void onProgressChanged(WebView v, int p) {
            if (p < 100) showProgress(p);
            if (p >= 10) inject();
        }

        @Override
        public Bitmap getDefaultVideoPoster() {
            return Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888);
        }

        @Override
        public void onShowCustomView(View view, CustomViewCallback cb) {
            if (customView != null) { cb.onCustomViewHidden(); return; }
            customView = view;
            customCb = cb;
            fullscreen.addView(view, new FrameLayout.LayoutParams(-1, -1));
            fullscreen.setVisibility(View.VISIBLE);
            setFullscreenBars(true);
            String rot = Prefs.str(MainActivity.this, Prefs.ROTATE);
            if ("landscape".equals(rot) || ("auto".equals(rot) && videoAspect >= 1f)) {
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
            } else if ("auto".equals(rot)) {
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT);
            }
            updateKeepAwake();
        }

        @Override
        public void onHideCustomView() {
            if (customView == null) return;
            fullscreen.removeView(customView);
            fullscreen.setVisibility(View.GONE);
            customView = null;
            setFullscreenBars(false);
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
            if (customCb != null) customCb.onCustomViewHidden();
            customCb = null;
            updateKeepAwake();
        }
    }

    private void setFullscreenBars(boolean on) {
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        lp.layoutInDisplayCutoutMode = on
                ? WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                : WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_DEFAULT;
        getWindow().setAttributes(lp);
        WindowInsetsController c = getWindow().getInsetsController();
        if (c == null) return;
        if (on) {
            c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            c.hide(WindowInsets.Type.systemBars());
        } else {
            c.show(WindowInsets.Type.systemBars());
        }
    }

    /** Messages from the page script. Called on a background thread. */
    private final class Bridge {
        @JavascriptInterface
        public void playing(boolean p) {
            ui.post(() -> {
                playing = p && onWatchPage();
                updateKeepAwake();
                updatePip();
            });
        }

        @JavascriptInterface
        public void video(int w, int h) {
            if (w <= 0 || h <= 0) return;
            ui.post(() -> {
                videoAspect = (float) w / h;
                updatePip();
            });
        }
    }

    // ------------------------------------------------------------------ playback extras

    private void updateKeepAwake() {
        boolean on = Prefs.bool(this, Prefs.KEEP_AWAKE) && (playing || customView != null);
        if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    /** Picture-in-picture starts by itself when you leave the app while a video plays. */
    private void updatePip() {
        if (!getPackageManager().hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)) return;
        try {
            float a = Math.max(0.42f, Math.min(2.38f, videoAspect));
            boolean auto = Prefs.bool(this, Prefs.PIP) && playing && onWatchPage();
            Intent i = new Intent(ACTION_PIP).setPackage(getPackageName());
            PendingIntent pi = PendingIntent.getBroadcast(this, 1, i,
                    PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            String name = playing ? "Pause" : "Play";
            RemoteAction ra = new RemoteAction(
                    Icon.createWithResource(this, Ui.iconId(this, playing ? "ic_pause" : "ic_play")),
                    name, name, pi);
            setPictureInPictureParams(new PictureInPictureParams.Builder()
                    .setAspectRatio(new Rational(Math.round(a * 1000), 1000))
                    .setAutoEnterEnabled(auto)
                    .setSeamlessResizeEnabled(true)
                    .setActions(Collections.singletonList(ra))
                    .build());
        } catch (Exception ignored) {}
    }

    @Override
    public void onPictureInPictureModeChanged(boolean inPip, Configuration cfg) {
        super.onPictureInPictureModeChanged(inPip, cfg);
        nav.setVisibility(inPip ? View.GONE : View.VISIBLE);
        progress.setVisibility(inPip ? View.GONE : View.VISIBLE);
        if (inPip && search.isOpen()) search.close();
        js("window.__LF&&__LF.pip(" + inPip + ")");
    }

    // ------------------------------------------------------------------ bar + search + menu

    @Override
    public void onTab(String id) {
        switch (id) {
            case NavBar.HOME: go("/", "pivot-w2w pivot-home"); break;
            case NavBar.SUBS: go("/feed/subscriptions", "pivot-subs"); break;
            case NavBar.YOU: go("/feed/you", "pivot-library pivot-you"); break;
            case NavBar.SEARCH: search.open(currentQuery()); break;
            case NavBar.MENU: showMenu(); break;
        }
    }

    /** Moves inside YouTube without reloading the whole page when it can. */
    private void go(String path, String pivotClasses) {
        if (!isYouTube(currentHost())) { web.loadUrl(BASE + path); return; }
        js("window.__LF?__LF.go(" + JSONObject.quote(path) + "," + JSONObject.quote(pivotClasses)
                + "):location.href=" + JSONObject.quote(BASE + path));
    }

    private String currentQuery() {
        Uri u = Uri.parse(currentUrl);
        if (u.getPath() != null && u.getPath().startsWith("/results")) return u.getQueryParameter("search_query");
        return "";
    }

    @Override
    public void onSearch(String q) {
        web.loadUrl(BASE + "/results?search_query=" + Uri.encode(q));
    }

    private void showMenu() {
        boolean in = isSignedIn();
        new Sheet(this, null)
                .row("ic_account", in ? "Switch Google account" : "Sign in to YouTube",
                        in ? "You're signed in" : "Link your YouTube account and Premium", false, this::signIn)
                .row("ic_tune", "Customise", "Shorts, ads, look, player and more", false,
                        () -> startActivity(new Intent(this, SettingsActivity.class)))
                .row("ic_refresh", "Reload", null, false, () -> web.reload())
                .row("ic_share", "Share this page", null, false, this::sharePage)
                .row("ic_copy", "Copy link", null, false, this::copyLink)
                .row("ic_open", "Open in browser", null, false, () -> openExternal(Uri.parse(shareUrl())))
                .show();
    }

    /** A tidy public link for the current page (youtu.be for videos). */
    private String shareUrl() {
        Uri u = Uri.parse(currentUrl);
        String p = u.getPath() == null ? "/" : u.getPath();
        if (p.startsWith("/watch") && u.getQueryParameter("v") != null) {
            String t = u.getQueryParameter("t");
            return "https://youtu.be/" + u.getQueryParameter("v") + (t != null ? "?t=" + t : "");
        }
        return currentUrl.replace("://m.youtube.com", "://www.youtube.com");
    }

    private void sharePage() {
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_TEXT, shareUrl());
        String title = web.getTitle();
        if (title != null) i.putExtra(Intent.EXTRA_SUBJECT, title);
        startActivity(Intent.createChooser(i, "Share"));
    }

    private void copyLink() {
        ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("Link", shareUrl()));
    }

    // ------------------------------------------------------------------ helpers

    private String readAsset(String name) {
        try (InputStream in = getAssets().open(name)) {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            return new String(bo.toByteArray(), StandardCharsets.UTF_8);
        } catch (Exception e) {
            return "";
        }
    }
}
