/*
 * Longform page script. Runs inside m.youtube.com.
 * The app injects it many times per page load, so it must be safe to run again:
 * the first run sets everything up, later runs just pass in the latest settings.
 */
(function () {
  'use strict';
  var cfg = window.__LF_CFG || {};
  if (window.__LF) { window.__LF.update(cfg); return; }

  var LF = window.__LF = {
    cfg: cfg, type: '', path: null, pipOn: false,
    inAd: false, wasMuted: false, speedKey: '', redirected: '', reported: null
  };
  var CSS = window.__LF_CSS || '';
  var dirty = true;

  // Cards that can hold a single video or Short.
  var CARD = [
    'ytm-rich-item-renderer', 'ytm-video-with-context-renderer', 'ytm-compact-video-renderer',
    'ytm-video-card-renderer', 'ytm-shorts-lockup-view-model', 'ytm-shorts-lockup-view-model-v2',
    'ytm-reel-item-renderer', 'yt-lockup-view-model', 'ytm-lockup-view-model'
  ].join(',');

  function root() { return document.documentElement; }

  function cls(name, on) {
    var r = root();
    if (r && r.classList.contains(name) !== !!on) r.classList.toggle(name, !!on);
  }

  function pageType() {
    var p = location.pathname || '/';
    if (p === '/' || p === '/index') return 'home';
    if (p.indexOf('/feed/subscriptions') === 0) return 'subs';
    if (p.indexOf('/results') === 0) return 'search';
    if (p.indexOf('/watch') === 0) return 'watch';
    if (p.indexOf('/shorts/') === 0) return 'short';
    if (/^\/(@|channel\/|c\/|user\/)/.test(p)) return 'channel';
    return 'other';
  }

  function hideShortsHere(t) {
    var c = LF.cfg;
    switch (t) {
      case 'home': return !!c.shortsHome;
      case 'subs': return !!c.shortsSubs;
      case 'search': return !!c.shortsSearch;
      case 'watch': return !!c.shortsWatch;
      case 'channel': return !c.shortsChannel;
      case 'short': return false;
      default: return !!c.shortsOther;
    }
  }

  function ensureStyle() {
    var r = root();
    if (!r) return false;
    var parent = document.head || r;
    var s = document.getElementById('lf-style');
    if (!s) { s = document.createElement('style'); s.id = 'lf-style'; s.textContent = CSS; }
    if (s.parentNode !== parent) parent.appendChild(s);
    var v = document.getElementById('lf-vars');
    if (!v) { v = document.createElement('style'); v.id = 'lf-vars'; }
    var c = LF.cfg;
    var vars = ':root{--lf-accent:' + (c.accent || '#3EA6FF') + ';--lf-radius:' +
      Math.max(0, c.radius | 0) + 'px;--lf-cols:' + Math.max(1, c.cols | 0) + '}';
    if (v.textContent !== vars) v.textContent = vars;
    if (v.parentNode !== parent) parent.appendChild(v);
    return true;
  }

  function apply() {
    if (!ensureStyle()) return;
    var c = LF.cfg, t = pageType(), feed = (t === 'home' || t === 'subs');
    LF.type = t;
    cls('lf-on', true);
    cls('lf-ns', hideShortsHere(t));
    cls('lf-ads', c.adBlock);
    cls('lf-promos', c.hidePromos);
    cls('lf-hw', c.hideWatched && (feed || t === 'search' || t === 'watch'));
    cls('lf-mixes', c.hideMixes && t !== 'channel' && t !== 'other');
    cls('lf-posts', c.hidePosts && feed);
    cls('lf-games', c.hideGames);
    cls('lf-comments', c.hideComments && t === 'watch');
    cls('lf-black', c.black);
    cls('lf-accent', c.accentProgress);
    cls('lf-round', (c.radius | 0) >= 0);
    cls('lf-cols', (c.cols | 0) > 1 && t === 'home');
    cls('lf-pip', LF.pipOn);
  }

  // ---- Shorts that CSS alone can't catch ----

  function shortId(href) {
    var m = /\/shorts\/([A-Za-z0-9_-]{5,})/.exec(href || '');
    return m ? m[1] : null;
  }

  function sweep() {
    var r = root();
    if (!r) return;
    // Un-mark anything that no longer holds a Short (YouTube reuses elements).
    var marked = document.querySelectorAll('[data-lf-short]');
    for (var k = 0; k < marked.length; k++) {
      var m = marked[k];
      var isChip = m.hasAttribute('data-lf-chip');
      var still = isChip ? (m.textContent || '').trim() === 'Shorts'
        : (m.matches('a[href*="/shorts/"]') || m.querySelector('a[href*="/shorts/"]'));
      if (!still) { m.removeAttribute('data-lf-short'); m.removeAttribute('data-lf-chip'); }
    }
    if (!r.classList.contains('lf-ns')) return;
    var links = document.querySelectorAll('a[href*="/shorts/"]');
    for (var i = 0; i < links.length; i++) {
      var box = links[i].closest(CARD) || links[i];
      if (!box.hasAttribute('data-lf-short')) box.setAttribute('data-lf-short', '');
    }
    var chips = document.querySelectorAll('ytm-chip-cloud-chip-renderer,yt-chip-cloud-chip-renderer,chip-view-model');
    for (var j = 0; j < chips.length; j++) {
      if ((chips[j].textContent || '').trim() === 'Shorts' && !chips[j].hasAttribute('data-lf-short')) {
        chips[j].setAttribute('data-lf-short', '');
        chips[j].setAttribute('data-lf-chip', '');
      }
    }
  }

  function shortRedirect() {
    if (LF.type !== 'short' || !LF.cfg.shortsToPlayer) return;
    var id = shortId(location.pathname);
    if (id && LF.redirected !== id) { LF.redirected = id; location.replace('/watch?v=' + id); }
  }

  document.addEventListener('click', function (e) {
    if (!LF.cfg.shortsToPlayer) return;
    var a = e.target && e.target.closest ? e.target.closest('a[href*="/shorts/"]') : null;
    if (!a) return;
    var id = shortId(a.getAttribute('href'));
    if (!id) return;
    e.preventDefault();
    e.stopImmediatePropagation();
    location.href = '/watch?v=' + id;
  }, true);

  // ---- Video player: ads, speed, playing state ----

  function player() { return document.querySelector('#movie_player, .html5-video-player'); }

  function isAd() {
    var p = player();
    return !!(p && (p.classList.contains('ad-showing') || p.classList.contains('ad-interrupting')));
  }

  function adTick() {
    if (!LF.cfg.adSkip) return;
    var p = player();
    if (!p) return;
    var v = p.querySelector('video');
    if (isAd()) {
      if (!LF.inAd) { LF.inAd = true; LF.wasMuted = v ? v.muted : false; }
      var b = document.querySelector('.ytp-ad-skip-button,.ytp-ad-skip-button-modern,.ytp-skip-ad-button,' +
        '.ytp-ad-skip-button-slot button,.ytp-ad-skip-button-container button,button[id^="skip-button"]');
      if (b) { try { b.click(); } catch (e) {} }
      if (v) {
        v.muted = true;
        if (isFinite(v.duration) && v.duration > 0 && v.currentTime < v.duration - 0.3) {
          try { v.currentTime = v.duration - 0.1; } catch (e) {}
        }
      }
    } else if (LF.inAd) {
      LF.inAd = false;
      if (v) v.muted = LF.wasMuted;
    }
  }

  function videoKey() {
    try { return new URLSearchParams(location.search).get('v') || location.pathname; }
    catch (e) { return location.pathname; }
  }

  function report(p) {
    if (LF.reported === p) return;
    LF.reported = p;
    try { if (window.LFNative) window.LFNative.playing(!!p); } catch (e) {}
  }

  function onMedia(e) {
    var v = e.target;
    if (!v || v.tagName !== 'VIDEO' || LF.type !== 'watch') return;
    if (e.type === 'playing' || e.type === 'loadedmetadata') {
      if (v.videoWidth && v.videoHeight && !isAd()) {
        try { if (window.LFNative) window.LFNative.video(v.videoWidth, v.videoHeight); } catch (x) {}
      }
      if (e.type === 'playing') {
        report(true);
        if (!isAd()) {
          var k = videoKey();
          if (LF.speedKey !== k) {
            LF.speedKey = k;
            var s = +LF.cfg.speed || 1;
            if (s !== 1) v.playbackRate = s;
          }
        }
      }
    } else if (e.type === 'pause' || e.type === 'ended') {
      report(false);
    }
  }
  ['playing', 'pause', 'ended', 'loadedmetadata'].forEach(function (n) {
    document.addEventListener(n, onMedia, true);
  });

  // ---- Main loop ----

  function tick() {
    var r = root();
    if (!r) return;
    if (!LF.observer && window.MutationObserver) {
      LF.observer = new MutationObserver(function () { dirty = true; });
      LF.observer.observe(r, { childList: true, subtree: true });
    }
    var key = location.pathname + location.search;
    var changed = key !== LF.path;
    apply();
    if (changed) {
      LF.path = key;
      dirty = true;
      if (LF.type !== 'watch') report(false);
      shortRedirect();
    }
    if (dirty) { dirty = false; sweep(); }
    adTick();
  }

  // ---- Called by the app ----

  LF.update = function (c) { LF.cfg = c || {}; LF.path = null; dirty = true; tick(); };
  LF.refresh = function () { LF.path = null; tick(); };
  LF.pip = function (on) { LF.pipOn = !!on; cls('lf-pip', LF.pipOn); };
  LF.pause = function () {
    var vs = document.querySelectorAll('video');
    for (var i = 0; i < vs.length; i++) { try { vs[i].pause(); } catch (e) {} }
  };
  LF.toggle = function () {
    var p = player();
    var v = (p && p.querySelector('video')) || document.querySelector('video');
    if (!v) return;
    if (v.paused) { var pr = v.play(); if (pr && pr.catch) pr.catch(function () {}); } else v.pause();
  };
  LF.go = function (path, classes) {
    if (location.pathname === path) {
      try { window.scrollTo({ top: 0, behavior: 'smooth' }); } catch (e) { window.scrollTo(0, 0); }
      return;
    }
    var before = location.pathname, list = (classes || '').split(' '), el = null;
    for (var i = 0; i < list.length && !el; i++) {
      if (list[i]) el = document.querySelector('ytm-pivot-bar-item-renderer .' + list[i]);
    }
    if (!el) { location.href = path; return; }
    el.click();
    // If YouTube ignored the tap, load the page normally.
    setTimeout(function () { if (location.pathname === before) location.href = path; }, 1200);
  };

  tick();
  setInterval(tick, 250);
  document.addEventListener('DOMContentLoaded', tick);
})();
