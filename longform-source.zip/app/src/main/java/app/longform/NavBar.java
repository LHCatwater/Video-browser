package app.longform;

import android.content.Context;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/** The app's own bottom navigation bar (replaces YouTube's, which has the Shorts tab). */
final class NavBar extends FrameLayout {

    interface Listener {
        void onTab(String id);
    }

    static final String HOME = "home", SUBS = "subs", SEARCH = "search", YOU = "you", MENU = "menu";

    private static final class Item {
        String id;
        FrameLayout pill;
        ImageView icon;
        TextView label;
    }

    private final Listener listener;
    private final List<Item> items = new ArrayList<>();
    private Ui.Pal pal;
    private String selected;

    NavBar(Context c, Listener l) {
        super(c);
        listener = l;
    }

    void build(Ui.Pal p, String style, boolean labels, boolean showSearch) {
        pal = p;
        removeAllViews();
        items.clear();
        Context c = getContext();
        boolean floating = !"flat".equals(style);

        setBackgroundColor(p.bg);
        LinearLayout bar = new LinearLayout(c);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        LayoutParams lp = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        if (floating) {
            lp.setMargins(Ui.dp(c, 12), Ui.dp(c, 4), Ui.dp(c, 12), Ui.dp(c, 10));
            bar.setBackground(Ui.round(p.surface, Ui.dp(c, 30)));
            bar.setElevation(Ui.dp(c, 3));
            bar.setPadding(Ui.dp(c, 4), Ui.dp(c, labels ? 6 : 7), Ui.dp(c, 4), Ui.dp(c, labels ? 5 : 7));
        } else {
            View line = new View(c);
            line.setBackgroundColor(p.line);
            addView(line, new LayoutParams(LayoutParams.MATCH_PARENT, Math.max(1, Ui.dp(c, 0.5f)), Gravity.TOP));
            bar.setPadding(0, Ui.dp(c, labels ? 7 : 9), 0, Ui.dp(c, labels ? 6 : 9));
        }
        addView(bar, lp);

        add(bar, HOME, "ic_home", "Home", labels);
        add(bar, SUBS, "ic_subs", "Subscriptions", labels);
        if (showSearch) add(bar, SEARCH, "ic_search", "Search", labels);
        add(bar, YOU, "ic_library", "You", labels);
        add(bar, MENU, "ic_tune", "Options", labels);
        select(selected);
    }

    private void add(LinearLayout bar, String id, String icon, String text, boolean labels) {
        Context c = getContext();
        Item it = new Item();
        it.id = id;

        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);

        it.pill = new FrameLayout(c);
        it.icon = new ImageView(c);
        it.icon.setImageDrawable(Ui.icon(c, icon, pal.sub));
        it.pill.addView(it.icon, new LayoutParams(Ui.dp(c, 22), Ui.dp(c, 22), Gravity.CENTER));
        col.addView(it.pill, new LinearLayout.LayoutParams(Ui.dp(c, 56), Ui.dp(c, 30)));

        it.label = new TextView(c);
        it.label.setText(text);
        it.label.setTextSize(11);
        it.label.setSingleLine(true);
        it.label.setTextColor(pal.sub);
        it.label.setGravity(Gravity.CENTER);
        it.label.setVisibility(labels ? VISIBLE : GONE);
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        tl.topMargin = Ui.dp(c, 2);
        col.addView(it.label, tl);

        col.setContentDescription(text);
        col.setOnClickListener(v -> listener.onTab(id));
        bar.addView(col, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        items.add(it);
    }

    void select(String id) {
        selected = id;
        if (pal == null) return;
        Context c = getContext();
        for (Item it : items) {
            boolean on = it.id.equals(id);
            int fg = on ? pal.accent : pal.sub;
            it.pill.setBackground(Ui.press(on ? Ui.alpha(pal.accent, 0.18f) : 0x00000000,
                    Ui.dp(c, 15), Ui.alpha(pal.text, 0.12f)));
            if (it.icon.getDrawable() != null) it.icon.getDrawable().setTint(fg);
            it.label.setTextColor(on ? pal.text : pal.sub);
            it.label.setTypeface(on ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        }
    }
}
