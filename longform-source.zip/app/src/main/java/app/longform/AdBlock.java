package app.longform;

import android.net.Uri;
import android.webkit.WebResourceResponse;

import java.io.ByteArrayInputStream;
import java.util.Locale;

/** Blocks requests to ad servers. Video ads that still get through are skipped by inject.js. */
final class AdBlock {
    private AdBlock() {}

    private static final String[] HOSTS = {
            "googleads.g.doubleclick.net",
            "ad.doubleclick.net",
            "pubads.g.doubleclick.net",
            "securepubads.g.doubleclick.net",
            "googleadservices.com",
            "pagead2.googlesyndication.com",
            "tpc.googlesyndication.com",
            "googletagservices.com",
            "adservice.google.com",
            "imasdk.googleapis.com",
            "s0.2mdn.net",
    };

    private static final String[] YT_PATHS = {
            "/pagead/",
            "/api/stats/ads",
            "/ptracking",
            "/get_midroll_info",
            "/pcs/activeview",
    };

    static boolean blocked(Uri u) {
        String h = u.getHost();
        if (h == null) return false;
        h = h.toLowerCase(Locale.ROOT);
        for (String d : HOSTS) {
            if (h.equals(d) || h.endsWith("." + d)) return true;
        }
        if (h.equals("youtube.com") || h.endsWith(".youtube.com")) {
            String p = u.getPath();
            if (p != null) {
                for (String pre : YT_PATHS) if (p.startsWith(pre)) return true;
            }
        }
        return false;
    }

    static WebResourceResponse empty() {
        return new WebResourceResponse("text/plain", "utf-8", new ByteArrayInputStream(new byte[0]));
    }
}
