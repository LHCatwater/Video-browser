package app.longform;

import android.content.Context;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.InputType;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextWatcher;
import android.text.style.StyleSpan;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Full-screen search with recent searches and YouTube suggestions. */
final class SearchPanel extends FrameLayout {

    interface Listener {
        void onSearch(String query);
    }

    private final Listener listener;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService net = Executors.newSingleThreadExecutor();
    private Ui.Pal p;
    private EditText input;
    private ImageView clear;
    private LinearLayout list;
    private int seq;
    private boolean open;
    private List<String> lastSuggestions = new ArrayList<>();
    private String lastSuggestFor = "";

    SearchPanel(Context c, Listener l) {
        super(c);
        listener = l;
        setClickable(true);
        build(Ui.pal(c));
    }

    void build(Ui.Pal pal) {
        p = pal;
        removeAllViews();
        Context c = getContext();
        setBackgroundColor(p.bg);

        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        addView(col, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));

        LinearLayout top = new LinearLayout(c);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(Ui.dp(c, 4), Ui.dp(c, 8), Ui.dp(c, 12), Ui.dp(c, 8));

        ImageView back = iconButton("ic_back", p.text);
        back.setContentDescription("Back");
        back.setOnClickListener(v -> close());
        top.addView(back, new LinearLayout.LayoutParams(Ui.dp(c, 48), Ui.dp(c, 48)));

        FrameLayout field = new FrameLayout(c);
        field.setBackground(Ui.round(p.surface, Ui.dp(c, 24)));
        input = new EditText(c);
        input.setBackground(null);
        input.setHint("Search YouTube");
        input.setHintTextColor(p.sub);
        input.setTextColor(p.text);
        input.setTextSize(16);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_AUTO_CORRECT);
        input.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        input.setPadding(Ui.dp(c, 18), 0, Ui.dp(c, 44), 0);
        input.setTextCursorDrawable(Ui.round(p.accent, Ui.dp(c, 1)));
        input.setOnEditorActionListener((v, actionId, e) -> {
            boolean enter = e != null && e.getKeyCode() == KeyEvent.KEYCODE_ENTER
                    && e.getAction() == KeyEvent.ACTION_DOWN;
            if (actionId == EditorInfo.IME_ACTION_SEARCH || enter) {
                submit(input.getText().toString());
                return true;
            }
            return false;
        });
        input.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int d) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int d) {}
            @Override public void afterTextChanged(Editable s) {
                clear.setVisibility(s.length() > 0 ? VISIBLE : GONE);
                refresh();
            }
        });
        field.addView(input, new LayoutParams(LayoutParams.MATCH_PARENT, Ui.dp(c, 48)));

        clear = iconButton("ic_close", p.sub);
        clear.setContentDescription("Clear");
        clear.setVisibility(GONE);
        clear.setOnClickListener(v -> input.setText(""));
        field.addView(clear, new LayoutParams(Ui.dp(c, 44), Ui.dp(c, 48), Gravity.END | Gravity.CENTER_VERTICAL));
        top.addView(field, new LinearLayout.LayoutParams(0, Ui.dp(c, 48), 1f));
        col.addView(top);

        ScrollView sv = new ScrollView(c);
        sv.setOverScrollMode(OVER_SCROLL_NEVER);
        list = new LinearLayout(c);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(0, 0, 0, Ui.dp(c, 16));
        sv.addView(list);
        col.addView(sv, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
    }

    private ImageView iconButton(String icon, int tint) {
        Context c = getContext();
        ImageView iv = new ImageView(c);
        iv.setImageDrawable(Ui.icon(c, icon, tint));
        iv.setScaleType(ImageView.ScaleType.CENTER);
        iv.setBackground(Ui.press(0x00000000, Ui.dp(c, 24), Ui.alpha(p.text, 0.12f)));
        return iv;
    }

    boolean isOpen() {
        return open;
    }

    void open(String prefill) {
        open = true;
        setVisibility(VISIBLE);
        input.setText(prefill == null ? "" : prefill);
        input.setSelection(input.getText().length());
        setAlpha(0f);
        setTranslationY(Ui.dp(getContext(), 18));
        animate().alpha(1f).translationY(0).setDuration(170).start();
        refresh();
        input.requestFocus();
        ui.postDelayed(() -> {
            InputMethodManager im = (InputMethodManager) getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
            if (im != null) im.showSoftInput(input, InputMethodManager.SHOW_IMPLICIT);
        }, 120);
    }

    void close() {
        if (!open) return;
        open = false;
        InputMethodManager im = (InputMethodManager) getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        if (im != null) im.hideSoftInputFromWindow(input.getWindowToken(), 0);
        animate().alpha(0f).translationY(Ui.dp(getContext(), 18)).setDuration(140)
                .withEndAction(() -> { if (!open) setVisibility(GONE); }).start();
    }

    private void submit(String q) {
        q = q.trim();
        if (q.isEmpty()) return;
        Prefs.addRecent(getContext(), q);
        close();
        listener.onSearch(q);
    }

    private void refresh() {
        String q = input.getText().toString().trim();
        render(q);
        final int mine = ++seq;
        if (q.isEmpty() || !Prefs.bool(getContext(), Prefs.SUGGEST)) return;
        ui.postDelayed(() -> {
            if (mine != seq) return;
            net.execute(() -> {
                List<String> s = fetch(q);
                ui.post(() -> {
                    if (mine != seq) return;
                    lastSuggestions = s;
                    lastSuggestFor = q;
                    render(q);
                });
            });
        }, 120);
    }

    private void render(String q) {
        list.removeAllViews();
        Context c = getContext();
        String ql = q.toLowerCase(Locale.ROOT);
        List<String> recent = Prefs.bool(c, Prefs.REMEMBER) ? Prefs.recent(c) : new ArrayList<>();
        List<String> shown = new ArrayList<>();

        int max = q.isEmpty() ? 15 : 3;
        for (String r : recent) {
            if (shown.size() >= max) break;
            if (q.isEmpty() || r.toLowerCase(Locale.ROOT).startsWith(ql)) {
                shown.add(r.toLowerCase(Locale.ROOT));
                addRow("ic_history", r, q, true);
            }
        }
        if (q.isEmpty()) {
            if (shown.isEmpty()) {
                TextView t = new TextView(c);
                t.setText(Prefs.bool(c, Prefs.REMEMBER) ? "Your recent searches will show here" : "Type to search");
                t.setTextColor(p.sub);
                t.setTextSize(14);
                t.setGravity(Gravity.CENTER);
                t.setPadding(0, Ui.dp(c, 40), 0, 0);
                list.addView(t);
            }
            return;
        }
        // Keep showing the previous suggestions while new ones load, unless the text changed completely.
        boolean related = !lastSuggestFor.isEmpty()
                && Character.toLowerCase(lastSuggestFor.charAt(0)) == ql.charAt(0);
        List<String> sugg = related ? lastSuggestions : new ArrayList<>();
        for (String s : sugg) {
            if (shown.contains(s.toLowerCase(Locale.ROOT))) continue;
            shown.add(s.toLowerCase(Locale.ROOT));
            addRow("ic_search", s, q, false);
        }
    }

    private void addRow(String icon, String text, String typed, boolean isRecent) {
        Context c = getContext();
        LinearLayout row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(Ui.dp(c, 20), 0, Ui.dp(c, 6), 0);
        row.setMinimumHeight(Ui.dp(c, 52));
        row.setBackground(Ui.press(0x00000000, 0, Ui.alpha(p.text, 0.10f)));

        ImageView iv = new ImageView(c);
        iv.setImageDrawable(Ui.icon(c, icon, p.sub));
        LinearLayout.LayoutParams il = new LinearLayout.LayoutParams(Ui.dp(c, 22), Ui.dp(c, 22));
        il.rightMargin = Ui.dp(c, 18);
        row.addView(iv, il);

        TextView t = new TextView(c);
        t.setTextSize(16);
        t.setTextColor(p.text);
        t.setSingleLine(true);
        t.setEllipsize(android.text.TextUtils.TruncateAt.END);
        SpannableString span = new SpannableString(text);
        String tl = text.toLowerCase(Locale.ROOT), ty = typed.toLowerCase(Locale.ROOT);
        if (!ty.isEmpty() && tl.startsWith(ty) && text.length() > typed.length()) {
            span.setSpan(new StyleSpan(Typeface.BOLD), typed.length(), text.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
        t.setText(span);
        row.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        ImageView end = iconButton(isRecent ? "ic_close" : "ic_fill", p.sub);
        end.setContentDescription(isRecent ? "Remove" : "Use this text");
        end.setOnClickListener(v -> {
            if (isRecent) {
                Prefs.removeRecent(c, text);
                render(input.getText().toString().trim());
            } else {
                input.setText(text + " ");
                input.setSelection(input.getText().length());
            }
        });
        row.addView(end, new LinearLayout.LayoutParams(Ui.dp(c, 44), Ui.dp(c, 44)));

        row.setOnClickListener(v -> submit(text));
        list.addView(row, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
    }

    /** Asks YouTube's suggestion service. Runs off the main thread. */
    private static List<String> fetch(String q) {
        List<String> out = new ArrayList<>();
        HttpURLConnection con = null;
        try {
            String lang = Locale.getDefault().getLanguage();
            URL u = new URL("https://suggestqueries.google.com/complete/search?client=firefox&ds=yt&ie=utf-8&oe=utf-8&hl="
                    + lang + "&q=" + URLEncoder.encode(q, "UTF-8"));
            con = (HttpURLConnection) u.openConnection();
            con.setConnectTimeout(4000);
            con.setReadTimeout(4000);
            try (InputStream in = con.getInputStream()) {
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                byte[] buf = new byte[4096];
                int n;
                while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
                JSONArray a = new JSONArray(new String(bo.toByteArray(), StandardCharsets.UTF_8));
                JSONArray s = a.getJSONArray(1);
                for (int i = 0; i < s.length() && i < 10; i++) out.add(s.getString(i));
            }
        } catch (Exception ignored) {
        } finally {
            if (con != null) con.disconnect();
        }
        return out;
    }
}
