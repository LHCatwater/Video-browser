package app.longform;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** A rounded panel that slides up from the bottom with a list of choices. */
final class Sheet {
    private final Context c;
    private final Ui.Pal p;
    private final Dialog dialog;
    private final LinearLayout box;

    Sheet(Context ctx, String title) {
        c = ctx;
        p = Ui.pal(ctx);
        dialog = new Dialog(ctx);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        box = new LinearLayout(c);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(Ui.dp(c, 8), Ui.dp(c, 10), Ui.dp(c, 8), Ui.dp(c, 16));
        float r = Ui.dp(c, 24);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(p.dark ? p.surface : p.card);
        bg.setCornerRadii(new float[]{r, r, r, r, 0, 0, 0, 0});
        box.setBackground(bg);

        View handle = new View(c);
        handle.setBackground(Ui.round(Ui.alpha(p.text, 0.25f), Ui.dp(c, 2)));
        LinearLayout.LayoutParams hl = new LinearLayout.LayoutParams(Ui.dp(c, 36), Ui.dp(c, 4));
        hl.gravity = Gravity.CENTER_HORIZONTAL;
        hl.bottomMargin = Ui.dp(c, 10);
        box.addView(handle, hl);

        if (title != null) {
            TextView t = new TextView(c);
            t.setText(title);
            t.setTextSize(18);
            t.setTypeface(Typeface.DEFAULT_BOLD);
            t.setTextColor(p.text);
            t.setPadding(Ui.dp(c, 16), Ui.dp(c, 2), Ui.dp(c, 16), Ui.dp(c, 10));
            box.addView(t);
        }
    }

    Sheet row(String icon, String text, String sub, boolean checked, Runnable action) {
        LinearLayout row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setMinimumHeight(Ui.dp(c, 52));
        row.setPadding(Ui.dp(c, 16), Ui.dp(c, 8), Ui.dp(c, 16), Ui.dp(c, 8));
        row.setBackground(Ui.press(0x00000000, Ui.dp(c, 14), Ui.alpha(p.text, 0.10f)));

        if (icon != null) {
            ImageView iv = new ImageView(c);
            iv.setImageDrawable(Ui.icon(c, icon, p.text));
            LinearLayout.LayoutParams il = new LinearLayout.LayoutParams(Ui.dp(c, 22), Ui.dp(c, 22));
            il.rightMargin = Ui.dp(c, 18);
            row.addView(iv, il);
        }

        LinearLayout texts = new LinearLayout(c);
        texts.setOrientation(LinearLayout.VERTICAL);
        TextView t = new TextView(c);
        t.setText(text);
        t.setTextSize(16);
        t.setTextColor(checked ? p.accent : p.text);
        if (checked) t.setTypeface(Typeface.DEFAULT_BOLD);
        texts.addView(t);
        if (sub != null) {
            TextView s = new TextView(c);
            s.setText(sub);
            s.setTextSize(13);
            s.setTextColor(p.sub);
            texts.addView(s);
        }
        row.addView(texts, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        if (checked) {
            ImageView ck = new ImageView(c);
            ck.setImageDrawable(Ui.icon(c, "ic_check", p.accent));
            row.addView(ck, new LinearLayout.LayoutParams(Ui.dp(c, 22), Ui.dp(c, 22)));
        }

        row.setOnClickListener(v -> {
            dialog.dismiss();
            if (action != null) action.run();
        });
        box.addView(row, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT));
        return this;
    }

    void show() {
        ScrollView sv = new ScrollView(c);
        sv.setOverScrollMode(View.OVER_SCROLL_NEVER);
        sv.addView(box);
        dialog.setContentView(sv);
        Window w = dialog.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(0));
            w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            w.setGravity(Gravity.BOTTOM);
            w.setWindowAnimations(android.R.style.Animation_InputMethod);
            w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            w.setDimAmount(0.45f);
        }
        dialog.show();
    }
}
