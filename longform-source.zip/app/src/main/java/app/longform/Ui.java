package app.longform;

import android.app.UiModeManager;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.util.TypedValue;

/** Colours, sizes and small drawing helpers shared by every screen. */
final class Ui {
    private Ui() {}

    static final int[] ACCENTS = {
            0xFF3EA6FF, 0xFFFF0033, 0xFFFF6B57, 0xFFFFB020, 0xFF7CC242,
            0xFF14B8A6, 0xFF6C7CFF, 0xFFA66BFF, 0xFFF0559B, 0xFFA8C7FA
    };
    static final String[] ACCENT_NAMES = {
            "Sky", "YouTube red", "Coral", "Amber", "Lime",
            "Teal", "Indigo", "Violet", "Pink", "Frost"
    };

    /** The colours for the current theme. */
    static final class Pal {
        boolean dark, black;
        int bg, surface, surface2, text, sub, line, accent;
        /** Settings screen page and card colours. */
        int page, card;
    }

    static boolean isDark(Context c) {
        return (c.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
    }

    static int accent(Context c) {
        int i = Prefs.num(c, Prefs.ACCENT);
        if (i < 0 || i >= ACCENTS.length) i = 0;
        return ACCENTS[i];
    }

    static Pal pal(Context c) {
        Pal p = new Pal();
        p.dark = isDark(c);
        p.black = p.dark && "black".equals(Prefs.str(c, Prefs.THEME));
        if (p.black) {
            p.bg = 0xFF000000; p.surface = 0xFF151515; p.surface2 = 0xFF222222;
            p.text = 0xFFF1F1F1; p.sub = 0xFF9A9A9A; p.line = 0x22FFFFFF;
            p.page = 0xFF000000; p.card = 0xFF121212;
        } else if (p.dark) {
            p.bg = 0xFF0F0F0F; p.surface = 0xFF1F1F1F; p.surface2 = 0xFF2B2B2B;
            p.text = 0xFFF1F1F1; p.sub = 0xFFAAAAAA; p.line = 0x22FFFFFF;
            p.page = 0xFF0F0F0F; p.card = 0xFF1C1C1C;
        } else {
            p.bg = 0xFFFFFFFF; p.surface = 0xFFF1F1F4; p.surface2 = 0xFFE4E4E9;
            p.text = 0xFF0F0F0F; p.sub = 0xFF5F6368; p.line = 0x1A000000;
            p.page = 0xFFF2F2F6; p.card = 0xFFFFFFFF;
        }
        p.accent = accent(c);
        return p;
    }

    /** Tells Android which light/dark mode this app should use. */
    static void applyNightMode(Context c) {
        UiModeManager m = (UiModeManager) c.getSystemService(Context.UI_MODE_SERVICE);
        if (m == null) return;
        String t = Prefs.str(c, Prefs.THEME);
        int mode;
        if ("light".equals(t)) mode = UiModeManager.MODE_NIGHT_NO;
        else if ("dark".equals(t) || "black".equals(t)) mode = UiModeManager.MODE_NIGHT_YES;
        else mode = UiModeManager.MODE_NIGHT_AUTO;
        try { m.setApplicationNightMode(mode); } catch (Exception ignored) {}
    }

    static int dp(Context c, float v) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v,
                c.getResources().getDisplayMetrics()));
    }

    static int alpha(int color, float a) {
        return Color.argb(Math.round(255 * a), Color.red(color), Color.green(color), Color.blue(color));
    }

    static GradientDrawable round(int color, float radiusPx) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radiusPx);
        return g;
    }

    /** A rounded background that shows a ripple when tapped. */
    static Drawable press(int color, float radiusPx, int rippleColor) {
        return new RippleDrawable(ColorStateList.valueOf(rippleColor),
                round(color, radiusPx), round(Color.WHITE, radiusPx));
    }

    static Drawable icon(Context c, String name, int tint) {
        int id = iconId(c, name);
        if (id == 0) return null;
        Drawable d = c.getDrawable(id);
        if (d == null) return null;
        d = d.mutate();
        d.setTint(tint);
        return d;
    }

    static int iconId(Context c, String name) {
        return c.getResources().getIdentifier(name, "drawable", c.getPackageName());
    }
}
